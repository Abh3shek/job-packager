#!/bin/bash
cd /code
python main.py